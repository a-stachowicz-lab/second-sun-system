# THE WHITE-BOX SYSTEM — PARALLEL SPACE

Independent system architecture focused on conflict-driven diagnosis, traceable path analysis, actionable intervention and solution architecture.

## GitHub Pages

1. Upload the contents of this folder to a GitHub repository.
2. Keep `index.html` in the repository root.
3. Keep the two image files inside `assets/`.
4. In GitHub, open **Settings → Pages**.
5. Select **Deploy from a branch**, choose the `main` branch and `/ (root)`, then save.

The website is designed to be served as a static GitHub Pages site.
